import './App.css';
import React from 'react'
import { useState, useEffect } from 'react';
//import { Validator } from 'validator';


function App() {

  const initvalues={email: "", password: ""};
  const[formValues,setFormValues]=useState(initvalues);
  const[formErrors,setFormErrors]=useState({});
  const [isSubmit, setisSubmit] = useState(false);

  const handleChange = (e) => {
  const { name,value }=e.target;
    setFormValues({...formValues, [name] : value});
    
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    setFormErrors(validate(formValues));
    setisSubmit(true);
  };

  useEffect(() =>{
    console.log(formErrors);
    if(Object.keys(formErrors).length === 0 && isSubmit){
      console.log(formValues);
    }
  },[formErrors,formValues,isSubmit]);

  
  const validate = (value) => {
    const errors ={};
    const reg = /^[a-zA-Z0-9]+@+[a-zA-Z0-9]+.+[A-z]/
    const regExp = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z0-9]{8,}$/
    if(reg.test(value.email)){
      if(regExp.test(value.password) ){
         alert("Login Successful");
         value.email="";
         value.password="";
      }
      else if(value.password === ""){
        alert("Password is required!");
      }
      else if(!regExp.test(value.password)){
        alert("Password is not valid");
      }
    }
    else if(value.email === ""){
      alert("Email is requied!");
    }
    else if(!reg.test(value.email)){
      alert("Email is not valid!");
    }
   
    return errors;
  };


  return (
    <div className="App">
      <form onSubmit={handleSubmit}>
        <h1>
          Login Form
        </h1>
        <div className='ui div'></div>
        <div className='ui form'>
          <div className='field'>
            <label>Email</label>
            <input type='text' name='email' placeholder='Email' value={formValues.email} onChange={handleChange} ></input>
          </div>
          
          <div className='field'>
          <label>Password</label>
          <input type='password' name='password' placeholder='Password' value={formValues.password} onChange={handleChange} ></input>
          </div>
        
          <button className='button'>Submit</button>
        </div>
      </form>
    </div>
  );
};

export default App;
